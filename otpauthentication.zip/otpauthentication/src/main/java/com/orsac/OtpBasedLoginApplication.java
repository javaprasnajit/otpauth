package com.orsac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OtpBasedLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(OtpBasedLoginApplication.class, args);
	}

}
