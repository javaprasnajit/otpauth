package com.orsac.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class OTPSystem {
    private String mobileNumber;
    private String otp;
    private Long expiryTime;



}
