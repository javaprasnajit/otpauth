package com.orsac.reposotory;

import com.orsac.model.UserRegister;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRegisterRepository extends JpaRepository<UserRegister,Integer> {
    UserRegister findByMobileNumber(String mobileNumber);
}
