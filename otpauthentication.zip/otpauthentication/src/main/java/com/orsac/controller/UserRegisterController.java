package com.orsac.controller;

import com.orsac.model.UserRegister;
import com.orsac.service.UserRegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserRegisterController {

    @Autowired
    private UserRegisterService userRegisterService;


    @PostMapping("/RegisterUser")
    public ResponseEntity<String> userLogin(@RequestBody UserRegister userRegister) {
        userRegisterService.registerUser(userRegister);
        return new ResponseEntity<String>("User Register Successfully", HttpStatus.CREATED);
    }
}
