package com.orsac.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.orsac.model.UserRegister;
import com.orsac.service.UserRegisterService;

@RestController
public class OtpSystem {

    private final static String authkey = "261927ACQuRIYVKV2c5f6953a5P1";
    private final static String template_id = "5f695597cac9234aa62eebc5";
    private static String otpAPI = "https://api.msg91.com/api/v5/otp";
    private static String retryAPI = "https://api.msg91.com/api/v5/otp/retry";
    private static String verifyAPI = "https://api.msg91.com/api/v5/otp/verify";
    private static String countryCode = "+91";

    @Autowired
    private UserRegisterService userRegisterService;

    @Autowired
    RestTemplate restTemplate;

    @PostMapping("/sendOtp")
    public ResponseEntity<String> userLogin(@RequestBody UserRegister userRegister) throws Exception {
        if (userRegister.getMobileNumber() != null) {
            UserRegister dbUser = userRegisterService.findUserByuserName(userRegister);
            if (dbUser != null) {
                HttpResponse<JsonNode> response = Unirest.get(otpAPI)
                        .queryString("mobile", countryCode + dbUser.getMobileNumber())
                        .queryString("authkey", authkey)
                        .queryString("template_id", template_id)
                        .asJson();
                return new ResponseEntity<String>(response.getBody().toString(), HttpStatus.valueOf(response.getStatus()));
            } else {
                return new ResponseEntity<String>("User not found.", HttpStatus.NOT_FOUND);
            }
        } else {
            return new ResponseEntity<String>("Required Parameter not found", HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/resendOtp")
    public ResponseEntity<String> resendOTP(@RequestBody UserRegister userRegister) throws Exception {
        if (userRegister.getMobileNumber() != null) {
            UserRegister dbUser = userRegisterService.findUserByuserName(userRegister);
            if (dbUser != null) {
                HttpResponse<JsonNode> response = Unirest.post(retryAPI)
                        .queryString("mobile", countryCode + dbUser.getMobileNumber())
                        .queryString("authkey", authkey)
                        .queryString("template_id", template_id)
                        .asJson();
                return new ResponseEntity<String>(response.getBody().toString(), HttpStatus.valueOf(response.getStatus()));
            } else {
                return new ResponseEntity<String>("User not found.", HttpStatus.NOT_FOUND);
            }
        } else {
            return new ResponseEntity<String>("Required Parameter not found", HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/verifyOtp")
    public ResponseEntity<String> verifyOTP(@RequestBody UserRegister userRegister) throws Exception {
        System.out.println(userRegister.getMobileNumber());
        System.out.println(userRegister.getOtp());
        HttpResponse<JsonNode> response = Unirest.post(verifyAPI)
                .queryString("mobile", countryCode + userRegister.getMobileNumber())
                .queryString("authkey", authkey)
                .queryString("template_id", template_id)
                .queryString("otp", userRegister.getOtp())
                .asJson();
        return new ResponseEntity<String>(response.getBody().toString(), HttpStatus.valueOf(response.getStatus()));

    }
}

