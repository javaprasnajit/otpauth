package com.orsac.controller;

import com.orsac.model.OTPSystem;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
public class OtpController {

    private Map<String, OTPSystem>otp_data=new HashMap<>();

    private final static String authkey="261927ACQuRIYVKV2c5f6953a5P1";
    private final static String template_id="5f695597cac9234aa62eebc5";

    @RequestMapping(value="/mobilenumber/{mobileNumber}",method = RequestMethod.POST)
    public ResponseEntity<Object> sendOTP(@PathVariable("mobileNumber") String mobileNumber ){

        OTPSystem otpsystem=new OTPSystem();
        otpsystem.setMobileNumber(mobileNumber);
        otpsystem.setOtp(String.valueOf(((int)(Math.random()*(1000 * 1000)))+1000));
        otpsystem.setExpiryTime(System.currentTimeMillis()+50000);
        otp_data.put(mobileNumber,otpsystem);
        return new ResponseEntity<Object>("OTP is send successfully", HttpStatus.OK);
    }
   @RequestMapping(value="/mobilenumber/{mobileNumber}",method = RequestMethod.PUT)
    public ResponseEntity<Object> veryfyOTP(@PathVariable("mobileNumber") String mobileNumber,
                                            @RequestBody OTPSystem requestBodyOtpSystem){

        if(requestBodyOtpSystem.getOtp()==null||requestBodyOtpSystem.getOtp().trim().length()<=0){
            return new ResponseEntity<>("please provide OTP",HttpStatus.BAD_REQUEST);
        }

        if(otp_data.containsKey(mobileNumber)){
            OTPSystem otpSystem=otp_data.get(mobileNumber);
            if(otpSystem!=null){
                if(otpSystem.getExpiryTime()>=System.currentTimeMillis()){
                    if(requestBodyOtpSystem.getOtp().equals((otpSystem.getOtp()))){
                        otp_data.remove((mobileNumber));
                        return new ResponseEntity<>("OTP is send Successfully",HttpStatus.OK);
                    }
                    return new ResponseEntity<>("invalid OTP",HttpStatus.BAD_REQUEST);
                }
                return new ResponseEntity<>("OTP is Expiry",HttpStatus.BAD_REQUEST);
            }
            return new ResponseEntity<>("Something went wrong..!!",HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>("mobileNumber not found",HttpStatus.NOT_FOUND);
    }
}
