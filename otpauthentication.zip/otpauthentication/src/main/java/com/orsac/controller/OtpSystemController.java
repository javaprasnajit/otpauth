package com.orsac.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class OtpSystemController {

    private final static String authkey="261927ACQuRIYVKV2c5f6953a5P1";
    private final static String template_id="261927ACQuRIYVKV2c5f6953a5P1";




}
