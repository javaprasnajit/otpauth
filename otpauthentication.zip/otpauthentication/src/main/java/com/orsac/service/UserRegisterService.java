package com.orsac.service;

import com.orsac.model.UserRegister;
import com.orsac.reposotory.UserRegisterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserRegisterService {

    @Autowired
    private UserRegisterRepository userRegisterRepository;

    public UserRegister registerUser(UserRegister userRegister){
        return userRegisterRepository.save(userRegister);
    }

}
